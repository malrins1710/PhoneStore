﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class NewCustomersController : Controller
    {
        // GET: AdminPages/NewCustomers
        public ActionResult Index()
        {
            return View();
        }
    }
}