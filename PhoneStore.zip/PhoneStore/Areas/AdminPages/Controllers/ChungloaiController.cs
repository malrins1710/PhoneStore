﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class ChungloaiController : Controller
    {
        private static bool isEdit = false;

        //Khu nhập dữ liệu
        [HttpGet]
        public ActionResult Index()
        {
            List<loaiSP> DS = new onlineTrade_datamodel().loaiSPs.OrderBy(x => x.maLoai).ToList<loaiSP>();
            ViewData["DSLoai"] = DS;
            return View();
        }
        //Khu xuất dữ liệu
        [HttpPost]
        public ActionResult Index(loaiSP l)
        {
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            // nếu không phải chỉnh sửa thì khi ấn sẽ thêm dữ liệu còn ngược lại thì sẽ chỉnh sửa theo mã loại
            if (!isEdit)
            db.loaiSPs.Add(l);
            else
            {
                loaiSP y = db.loaiSPs.Find(l.maLoai);
                y.tenLoai = l.tenLoai;
                y.ghiChu = l.ghiChu;
                isEdit = false;
            }
            db.SaveChanges();
            // cập nhật lại danh sách trên view
            if (ModelState.IsValid)
                ModelState.Clear();
            ViewData["DSLoai"] = db.loaiSPs.OrderBy(x => x.maLoai).ToList<loaiSP>(); // kiểu viết tắc từ ở trên
            return View();
        }
        [HttpPost]
        public ActionResult Delete(string rmml)
        {
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            //Đổi string thành int
            int ma = int.Parse(rmml);
            //tìm object loaiSP in data model by maloai
            loaiSP f = db.loaiSPs.Find(ma);
            //xóa dữ liệu
            db.loaiSPs.Remove(f);
            //update vào database
            db.SaveChanges();
            //update database lên view
            ViewData["DSLoai"] = db.loaiSPs.OrderBy(x => x.maLoai).ToList<loaiSP>();
            return View("Index");
        }
        [HttpPost]
        public ActionResult Edit(string editml)
        {
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            //Đổi string thành int
            int ma = int.Parse(editml);
            //tìm object loaiSP in data model by maloai
            loaiSP f = db.loaiSPs.Find(ma);

            isEdit = true;
            //update database lên view
            ViewData["DSLoai"] = db.loaiSPs.OrderBy(x => x.maLoai).ToList<loaiSP>();
            return View("Index", f);
        }
    }
}