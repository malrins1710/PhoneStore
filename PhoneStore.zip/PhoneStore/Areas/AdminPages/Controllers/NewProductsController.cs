﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;
using PhoneStore.Areas.AdminPages.Models;   // lấy tài khoản đã đăng nhập ở login gán vào
using System.IO;    // xuất nhập
namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class NewProductsController : Controller
    {
        private static onlineTrade_datamodel db = new onlineTrade_datamodel();

        [HttpGet]
        public ActionResult Index()
        {
            sanPham x = new sanPham();
            x.ngayDangSP = DateTime.Now;
            x.tkThanhVien = Dungnhieu.gettaikhoan();
            // úp tạm hình
            ViewBag.ddHinh = "~/Malrins/images/6.png";
            return View(x);
        }
        [HttpPost]
        // vô hiệu hóa bảo mật nội dung truyền vào
        [ValidateInput(false)]
        public ActionResult Index(sanPham sp, HttpPostedFileBase HinhDaiDien)
        {
            try
            {
                sp.duocHT = false;
                sp.tkThanhVien = Dungnhieu.gettaikhoan();
                sp.ngayDangSP = DateTime.Now;
                //đang làm tới hình đại diện 1:09:00
                // nếu up được hình thì lưu lại còn ko thì bỏ trống
                if (HinhDaiDien != null)
                {
                    //lưu vào thư mục
                    string virPath = "/Malrins/ImagesProducts/"; // xác định vị trí lưu hình
                    string phyPath = Server.MapPath("~/" + virPath);
                    // lưu tên file theo định dạng hình
                    string ext = Path.GetExtension(HinhDaiDien.FileName);
                    string tenF = "HinhSP" + sp.maSP.ToString() + ext;
                    // lưu hình
                    HinhDaiDien.SaveAs(phyPath + tenF);
                    sp.hinhDD = virPath + tenF;
                    //cập nhật hình
                    ViewBag.ddHinh = sp.hinhDD;
                }
                else
                    sp.hinhDD = "";

                db.sanPhams.Add(sp);
                db.SaveChanges();
                return RedirectToAction("Index", "Selling");
            }
            catch
            {

            }
            return View(sp);
        }
    }
}