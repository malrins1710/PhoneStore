﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class KhachHangController : Controller
    {
        private static onlineTrade_datamodel db = new onlineTrade_datamodel();
        private void CapNhatView()
        {
            List<donHang> l = new onlineTrade_datamodel().donHangs.OrderBy(x => x.tenKH).ToList<donHang>();
            ViewData["DSKH"] = l;
        }
        // phân biệt chỉnh sửa hay là thêm mới khách hàng
        private static bool isEdit = false;
        [HttpGet]
        public ActionResult Index()
        {
            donHang x = new donHang();
            x.daKichHoat = false;
            x.tdGiaoHang = DateTime.Now;
            x.tdDatHang = DateTime.Now;
            CapNhatView();
            return View();
        }
        // Chỉnh sửa , thêm cột khách hàng mới
        [HttpPost]
        public ActionResult Index(donHang x)
        {
            x.maDH = string.Format("{0:ddhhmm}", DateTime.Now);
            x.daKichHoat = false;
            x.tdGiaoHang = DateTime.Now;
            x.tdDatHang = DateTime.Now;
            x.dcGiaoHang = x.diaChi;
            // nếu là thêm thì sẽ add còn ngược lại thì chỉ chỉnh sửa
            if (!isEdit)
            db.donHangs.Add(x);
            else
            {
                donHang d = db.donHangs.Find(x.maDH);
                d.tenKH = x.tenKH;
                d.gioiTinh = x.gioiTinh;
                d.soDT = x.soDT;
                d.diaChi = x.diaChi;
                d.email = x.email;
                d.tongtien = x.tongtien;
                d.maDH = x.maDH;
                d.tdDatHang = x.tdDatHang;
                d.ghiChu = x.ghiChu;
                isEdit = false;
            }
            db.SaveChanges();
            // Xóa hết chữ trong form sau khi lưu thành công
            if (ModelState.IsValid)
                ModelState.Clear();
            //update view
            CapNhatView();
            return View(x);
        }
        [HttpPost]
        public ActionResult Delete(string dl)
        {
            int ma = int.Parse(dl);         // chuyển đổi string sang int
            donHang f = db.donHangs.Find(dl); // tìm không được sẽ trở về là null
            db.donHangs.Remove(f);
            db.SaveChanges();
            CapNhatView();
            return View("Index");
        }
        [HttpPost]
        public ActionResult Edit(string edit)
        {
            int ma = int.Parse(edit);
            donHang f = db.donHangs.Find(edit);
            // nếu là Edit thì sẽ chỉnh sửa
            isEdit = true;
            CapNhatView();
            return View("Index", f);
        }
    }
}