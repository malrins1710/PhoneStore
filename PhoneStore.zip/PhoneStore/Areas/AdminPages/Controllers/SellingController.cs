﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class SellingController : Controller
    {
        private static onlineTrade_datamodel db = new onlineTrade_datamodel();
        private void CapNhatView()
        {
            List<sanPham> sp = db.sanPhams.OrderBy(x => x.maSP).ToList<sanPham>();
            ViewData["DSSP"] = sp;
        }

        public ActionResult Index()
        {
            CapNhatView();
            return View();
        }

        public ActionResult Delete(string dlsp)
        {
            int ma = int.Parse(dlsp);
            sanPham f = db.sanPhams.Find(ma);
            db.sanPhams.Remove(f);
            db.SaveChanges();
            CapNhatView();
            return View("Index");
        }
    }
}