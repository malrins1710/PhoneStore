﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;
using PhoneStore.Areas.AdminPages.Models;
using System.IO;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class NewArticlesController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            baiViet bv = new baiViet();
            bv.soLanDoc = 0;
            bv.ngayDang = DateTime.Now;
            //taiKhoan tk = Session["TtDangNhap"] as taiKhoan; //viết thông thường về lấy tài khoản đăng nhập từ hệ thống
            //bv.taiKhoan = tk.tkThanhVien;

            ////lấy tài khoản dn qua model
            bv.tkThanhVien = Dungnhieu.gettaikhoan();
            // Đưa đường dẫn hình ảnh ra hiển thị có sẵn lên khung upload
            ViewBag.HinhAnh = "~/Malrins/ImagesAdmin/default-150x150.png";
            return View(bv);
        }
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Index(baiViet x, HttpPostedFileBase HinhDaiDien)
        {
            try
            {
                x.tkThanhVien = Dungnhieu.gettaikhoan();
                x.ngayDang = DateTime.Now;
                x.soLanDoc = 0;
                //lưu hình vào thư mục chứa bài viết và post lên view
                if (HinhDaiDien != null)
                {
                    string virpath = "/Malrins/ImagesBlogs/";
                    string physicalpath = Server.MapPath("~/" + virpath); //xác định vị trí lưu hình sau khi upload
                    string ext = Path.GetExtension(HinhDaiDien.FileName);
                    string tenFile = "HDD" + x.maBV.ToString() + ext;
                    HinhDaiDien.SaveAs(physicalpath + tenFile);             //lưu hình ảnh dựa vào dd vật lý [drive][path][filename]
                    x.hinhDD = virpath + tenFile;                       //đường dẫn ảo theo domain
                                                                        //post hình lên
                    ViewBag.HinhAnh = x.hinhDD;
                }
                else
                    x.hinhDD = ""; // nếu sai thì ko cập nhật hình được

                // mặc định mới đăng bài là chưa duyệt
                x.daDuyet = false;
                //Thêm vào database và lưu dữ liệu
                onlineTrade_datamodel db = new onlineTrade_datamodel();
                db.baiViets.Add(x);
                db.SaveChanges();
                // nếu đăng thành công thì truyền đến trang danh sách chưa duyệt
                return RedirectToAction("Index", "ArticlesList", new { IsActive = 0 });
            }
            catch
            {
            }
            return View(x);
        }
    }
}