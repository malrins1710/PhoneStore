﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;
namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class ArticlesListController : Controller
    {
        // gọi để mốt đem vô cho dễ
        private static onlineTrade_datamodel db = new onlineTrade_datamodel();
        private static bool trangthai;
        // tạo hàm gọi để cập nhật vào các view
        private void CapnhatView()
        {
            List<baiViet> l = db.baiViets.Where(x => x.daDuyet == trangthai).ToList<baiViet>();
            ViewData["DSBLOG"] = l;
            ViewBag.Nutkiemduyet = trangthai ? "Bỏ duyệt" : "Xét duyệt";
        }

        [HttpGet]
        public ActionResult Index(string IsActive)
        {
            trangthai = IsActive!=null && IsActive.Equals("1");
            CapnhatView();
            return View();
        }
        [HttpPost]
        public ActionResult Delete(string mabv)
        {
            // Chuyển string thành int
            int ma = int.Parse(mabv);
            // Tìm và xóa bài viết theo mã bài viết
            baiViet f = db.baiViets.Find(ma);
            db.baiViets.Remove(f);
            // Cập nhật database
            db.SaveChanges();
            // Cập nhật database lên View
            CapnhatView();
            return View("Index");
        }
        [HttpPost]
        public ActionResult Active(string mabv)
        {
            // Chuyển string thành int
            int ma = int.Parse(mabv);
            // Tìm và duyệt bài viết
            baiViet f = db.baiViets.Find(ma);
            f.daDuyet = !trangthai; //!trang thai = (trangthai? false: true)
            // Cập nhật database
            db.SaveChanges();
            CapnhatView();
            return View("Index");
        }
        public ActionResult Details(string edit)
        {
            
            return RedirectToAction("Index", "NewArticles");
        }
    }
}