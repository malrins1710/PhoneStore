﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;

namespace PhoneStore.Areas.AdminPages.Controllers
{
    public class ProductsController : Controller
    {
        private static onlineTrade_datamodel db = new onlineTrade_datamodel();
        private static bool trangthai;
        private void Capnhatview()
        {
            List<donHang> dh = db.donHangs.Where(x => x.daKichHoat == trangthai).ToList<donHang>();
            ViewBag.Nutgiaohang = trangthai ? "Hủy đơn hàng" : "Giao hàng lại";
            ViewData["DSDH"] = dh;
        }
        
        [HttpGet]
        public ActionResult Index(string IsActive)
        {
            trangthai = IsActive!=null && IsActive.Equals("1");
            Capnhatview();
            return View();
        }
        [HttpPost]
        public ActionResult Delete(string rm)
        {
            donHang f = db.donHangs.Find(rm);
            db.donHangs.Remove(f);
            db.SaveChanges();
            Capnhatview();
            return View("Index");
        }
        [HttpPost]
        public ActionResult Giaohang(string gh)
        {
            donHang f = db.donHangs.Find(gh);
            f.daKichHoat = !trangthai;
            db.SaveChanges();
            Capnhatview();
            return View("Index");
        }
    }
}