﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using PhoneStore.Models;
namespace PhoneStore.Areas.AdminPages.Models
{
    public class Dungnhieu
    {
        public static taiKhoan getAccount()
        {
            taiKhoan tk = new taiKhoan();
            tk = HttpContext.Current.Session["TtDangNhap"] as taiKhoan;
            return tk;
        }
        /// <summary>
        /// lấy tài khoản đã đăng nhập ra hệ thống
        /// </summary>
        /// <returns></returns>
        public static string gettaikhoan()
        {
            return getAccount().tkThanhVien; 
        }
    }
}