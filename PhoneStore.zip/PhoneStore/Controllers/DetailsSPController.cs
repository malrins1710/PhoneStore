﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;

namespace PhoneStore.Controllers
{
    public class DetailsSPController : Controller
    {
        // GET: DetailsSP
        public ActionResult Index(int masp)
        {
            // dựa vào LINQ để lấy chi tiết sản phẩm từ model
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            sanPham sp = db.sanPhams.Where(x => x.maSP.Equals(masp)).First<sanPham>();
            ViewData["SpCanXem"] = sp;
            return View();
        }
    }
}