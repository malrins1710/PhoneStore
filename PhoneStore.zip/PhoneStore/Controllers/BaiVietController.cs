﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PhoneStore.Controllers
{
    public class BaiVietController : Controller
    {
        // GET: BaiViet
        public ActionResult Index()
        {
            return View();
        }
    }
}