﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;
namespace PhoneStore.Controllers
{
    public class DetailsBlogController : Controller
    {
        // GET: DetailsBlog
        public ActionResult Index(int mabv)
        {
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            baiViet bv = db.baiViets.Where(x => x.maBV == mabv).First<baiViet>();
            ViewData["chitietblog"] = bv;
            return View();
        }
    }
}