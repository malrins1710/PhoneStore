﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using PhoneStore.Models;
namespace PhoneStore.Controllers
{
    public class LoginController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(string Acc, string Pass)
        {
            string mk = BaoMat.baomatSHA256(Pass);
            // so sánh thông tin từ database qua model để xem sét dữ liệu chính xác hay không
            taiKhoan tkdn = new onlineTrade_datamodel().taiKhoans.Where(x => x.tkThanhVien.Equals(Acc.ToLower().Trim()) && x.matKhau.Equals(mk)).FirstOrDefault<taiKhoan>();
            // Kiểm tra nếu dữ liệu so sánh đúng thì trả view trực tiếp về Home private pages
            bool IsAuthentic = tkdn != null && tkdn.tkThanhVien.Equals(Acc.ToLower().Trim()) && tkdn.matKhau.Equals(mk);
            if (IsAuthentic)
            {
                Session["TtDangNhap"] = tkdn;
                return RedirectToAction("Index", "Dashboard", new { area = "AdminPages" });
            }
            return View();
        }
    }
}