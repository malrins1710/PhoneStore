﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Security.Cryptography;
using System.Text;

namespace PhoneStore.Models
{
    public class BaoMat
    {
        public static string baomatSHA256(string PlainText)
        {
            string result = "";
            using (SHA256 bm = SHA256.Create())
            {
                // biến chuỗi thành mảng bytes
                byte[] Data = Encoding.UTF8.GetBytes(PlainText);
                // tính hàm băm và trả về mảng
                byte[] hashResult = bm.ComputeHash(Data);
                result = BitConverter.ToString(hashResult);
            }
            return result;
        }
    }
}