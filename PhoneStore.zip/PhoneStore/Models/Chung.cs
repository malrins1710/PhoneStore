﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PhoneStore.Models
{
    public class Chung
    {

        // lấy ra sản phẩm-======================================

        public static List<sanPham> getProducts()
        {
            List<sanPham> l = new List<sanPham>();
            // Khai báo 1 tên đại diện cho database
            DbContext cn = new DbContext("name=onlineTrade_datamodel");
            // Lấy dữ liệu
            l = cn.Set<sanPham>().ToList<sanPham>();
            return l;
        }
        // lấy ra loại sản phẩm-===============================

        public static List<loaiSP> getCategories()
        {
            // viết gọn lại từ phía trên
            return new DbContext("name=onlineTrade_datamodel").Set<loaiSP>().ToList<loaiSP>();
        }

        // lấy ra sản phẩm theo loại-==============================

        public static List<sanPham> getProductsbyloaiSP(int maloai)
        {
            List<sanPham> l = new List<sanPham>();
            // Khai báo 1 tên đại diện cho database
            DbContext cn = new DbContext("name=onlineTrade_datamodel");
            // Lấy dữ liệu
            l = cn.Set<sanPham>().Where(x => x.maLoai == maloai).ToList<sanPham>();
            return l;
        }

        // lấy ra bài viết-====================================

        public static List<baiViet> getBlog(int n)
        {
            List<baiViet> l = new List<baiViet>();
            onlineTrade_datamodel db = new onlineTrade_datamodel();
            // chỉ lấy những bài đã duyệt và sắp xếp theo ngày đăng
            l = db.baiViets.Where(m => m.daDuyet == true).OrderByDescending(bv => bv.ngayDang).Take(n).ToList<baiViet>();
            return l;
        }
    }
}