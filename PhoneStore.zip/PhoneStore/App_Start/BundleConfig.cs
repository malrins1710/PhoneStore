﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Web.Optimization;
namespace PhoneStore.App_Start
{
    public class BundleConfig
    {
        public static void BundleRegister(BundleCollection bundle)
        {
            // css của layout public
            bundle.Add(new StyleBundle("~/bundles/css1").Include("~/Content/bootstrap.min.css", "~/Content/style.css", 
                                                                 "~/Content/responsive.css", "~/Content/jquery.mCustomScrollbar.min.css",
                                                                 "~/Content/owl.carousel.min.css", "~/Content/owl.theme.default.min.css"));
            // css của layout private
            bundle.Add(new StyleBundle("~/bundles/css2").Include("~/Content/CssAdmin/all.min.css", "~/Content/CssAdmin/adminlte.min.css"));

            // css của trang chi tiết sản phẩm và bài viết
            bundle.Add(new StyleBundle("~/bundles/css3").Include("~/Content/CssAdd/animate.css", "~/Content/CssAdd/bootsrap.min.css",
                                                                 "~/Content/CssAdd/font-awesome.min.css", "~/Content/CssAdd/main.css",
                                                                 "~/Content/CssAdd/prettyPhoto.css", "~/Content/CssAdd/price-range.css",
                                                                 "~/Content/CssAdd/responsive.css"));
            // js của layout public
            bundle.Add(new ScriptBundle("~/bundles/moder").Include("~/Scripts/modernizr-2.6.2.js"));
            bundle.Add(new ScriptBundle("~/bundles/scripts1").Include("~/Scripts/jquery.min.js", "~/Scripts/popper.min.js", "~/Scripts/bootstrap.bundle.min.js", 
                                                                     "~/Scripts/jquery-3.0.0.min.js", "~/Scripts/plugin.js",
                                                                     "~/Scripts/jquery.mCustomScrollbar.concat.min.js", "~/Scripts/custom.js",
                                                                     "~/Scripts/owl.carousel.js"));
            // js của layout private
            bundle.Add(new ScriptBundle("~/bundles/scripts2").Include("~/Scripts/JsAdmin/jquery.min.js", "~/Scripts/JsAdmin/bootstrap.bundle.min.js",
                                                                     "~/Scripts/JsAdmin/adminlte.min.js", "~/Scripts/JsAdmin/demo.js", "~/Scripts/JsAdmin/jquery.dataTables.min.js",
                                                                     "~/Scripts/JsAdmin/dataTables.bootstrap4.min.js", "~/Scripts/JsAdmin/dataTables.responsive.min.js",
                                                                     "~/Scripts/JsAdmin/responsive.bootstrap4.min.js", "~/Scripts/JsAdmin/dataTables.buttons.min.js",
                                                                     "~/Scripts/JsAdmin/buttons.bootstrap4.min.js", "~/Scripts/JsAdmin/jszip.min.js",
                                                                     "~/Scripts/JsAdmin/pdfmake.min.js", "~/Scripts/JsAdmin/vfs_fonts.js", "~/Scripts/JsAdmin/buttons.html5.min.js",
                                                                     "~/Scripts/JsAdmin/buttons.print.min.js", "~/Scripts/JsAdmin/buttons.colVis.min.js"));
            // js của trang chi tiết sp và bài viết
            bundle.Add(new ScriptBundle("~/bundles/scripts3").Include("~/Scripts/JsAdd/bootstrap.min.js", "~/Scripts/JsAdd/jquery.js",
                                                                      "~/Scripts/JsAdd/jquery.prettyPhoto.js", "~/Scripts/JsAdd/jquery.scrollUp.min.js",
                                                                      "~/Scripts/JsAdd/main.js", "~/Scripts/JsAdd/price-range.js"));
        }
    }
}